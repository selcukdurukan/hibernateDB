--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.0
-- Dumped by pg_dump version 15.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE hibernatedb;
--
-- Name: hibernatedb; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE hibernatedb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Turkish_Turkey.1254';


ALTER DATABASE hibernatedb OWNER TO postgres;

\connect hibernatedb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: billings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.billings (
    oid bigint NOT NULL,
    account_no bigint NOT NULL,
    account_type character varying(255) NOT NULL,
    user_id bigint
);


ALTER TABLE public.billings OWNER TO postgres;

--
-- Name: billings_oid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.billings_oid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.billings_oid_seq OWNER TO postgres;

--
-- Name: billings_oid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.billings_oid_seq OWNED BY public.billings.oid;


--
-- Name: contacts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contacts (
    oid bigint NOT NULL,
    address character varying(100) NOT NULL,
    email character varying(100) NOT NULL,
    phone_number character varying(100)
);


ALTER TABLE public.contacts OWNER TO postgres;

--
-- Name: contacts_oid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.contacts_oid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contacts_oid_seq OWNER TO postgres;

--
-- Name: contacts_oid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.contacts_oid_seq OWNED BY public.contacts.oid;


--
-- Name: magazines; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.magazines (
    oid bigint NOT NULL,
    genre character varying(50) NOT NULL,
    name character varying(50) NOT NULL,
    price double precision NOT NULL
);


ALTER TABLE public.magazines OWNER TO postgres;

--
-- Name: magazines_oid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.magazines_oid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.magazines_oid_seq OWNER TO postgres;

--
-- Name: magazines_oid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.magazines_oid_seq OWNED BY public.magazines.oid;


--
-- Name: magazines_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.magazines_users (
    magazines_oid bigint NOT NULL,
    readers_oid bigint NOT NULL
);


ALTER TABLE public.magazines_users OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    oid bigint NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    contact_id bigint
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_oid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_oid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_oid_seq OWNER TO postgres;

--
-- Name: users_oid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_oid_seq OWNED BY public.users.oid;


--
-- Name: billings oid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.billings ALTER COLUMN oid SET DEFAULT nextval('public.billings_oid_seq'::regclass);


--
-- Name: contacts oid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contacts ALTER COLUMN oid SET DEFAULT nextval('public.contacts_oid_seq'::regclass);


--
-- Name: magazines oid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.magazines ALTER COLUMN oid SET DEFAULT nextval('public.magazines_oid_seq'::regclass);


--
-- Name: users oid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN oid SET DEFAULT nextval('public.users_oid_seq'::regclass);


--
-- Data for Name: billings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.billings (oid, account_no, account_type, user_id) FROM stdin;
\.
COPY public.billings (oid, account_no, account_type, user_id) FROM '$$PATH$$/3355.dat';

--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contacts (oid, address, email, phone_number) FROM stdin;
\.
COPY public.contacts (oid, address, email, phone_number) FROM '$$PATH$$/3357.dat';

--
-- Data for Name: magazines; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.magazines (oid, genre, name, price) FROM stdin;
\.
COPY public.magazines (oid, genre, name, price) FROM '$$PATH$$/3359.dat';

--
-- Data for Name: magazines_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.magazines_users (magazines_oid, readers_oid) FROM stdin;
\.
COPY public.magazines_users (magazines_oid, readers_oid) FROM '$$PATH$$/3360.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (oid, first_name, last_name, contact_id) FROM stdin;
\.
COPY public.users (oid, first_name, last_name, contact_id) FROM '$$PATH$$/3362.dat';

--
-- Name: billings_oid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.billings_oid_seq', 4, true);


--
-- Name: contacts_oid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contacts_oid_seq', 1, true);


--
-- Name: magazines_oid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.magazines_oid_seq', 1, true);


--
-- Name: users_oid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_oid_seq', 2, true);


--
-- Name: billings billings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.billings
    ADD CONSTRAINT billings_pkey PRIMARY KEY (oid);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (oid);


--
-- Name: magazines magazines_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.magazines
    ADD CONSTRAINT magazines_pkey PRIMARY KEY (oid);


--
-- Name: magazines_users magazines_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.magazines_users
    ADD CONSTRAINT magazines_users_pkey PRIMARY KEY (magazines_oid, readers_oid);


--
-- Name: billings uk_m8b5k4qihy07dbnpwc18t2om3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.billings
    ADD CONSTRAINT uk_m8b5k4qihy07dbnpwc18t2om3 UNIQUE (account_no);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (oid);


--
-- Name: magazines_users fk44tcg6nevkskom7kqogywojny; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.magazines_users
    ADD CONSTRAINT fk44tcg6nevkskom7kqogywojny FOREIGN KEY (magazines_oid) REFERENCES public.magazines(oid);


--
-- Name: magazines_users fk8lm1tbkq1b7ud5bbh1ooh2pif; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.magazines_users
    ADD CONSTRAINT fk8lm1tbkq1b7ud5bbh1ooh2pif FOREIGN KEY (readers_oid) REFERENCES public.users(oid);


--
-- Name: users fk9s0tlg428ntp5edfquo0r9jxs; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk9s0tlg428ntp5edfquo0r9jxs FOREIGN KEY (contact_id) REFERENCES public.contacts(oid);


--
-- Name: billings fksasw24o7ksqkcikuhq9kt9lmk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.billings
    ADD CONSTRAINT fksasw24o7ksqkcikuhq9kt9lmk FOREIGN KEY (user_id) REFERENCES public.users(oid);


--
-- PostgreSQL database dump complete
--

